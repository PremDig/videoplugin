<?php
/**
 * Sidebar template.
 * The template can be overridden by copying it to yourtheme/vimeotheque/global/sidebar.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_sidebar( 'videos' );
