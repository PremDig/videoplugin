<?php
/**
 * Template for video post media; displays the attached video embed.
 */
?>

<div class="media video-embed vimeotheque-video-embed">
	<?php
		// embed the video
		vimeotheque_the_video_embed();
	?>
</div>

