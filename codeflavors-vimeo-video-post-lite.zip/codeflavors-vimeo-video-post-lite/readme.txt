=== Vimeotheque – Vimeo WordPress Plugin & Video Gallery ===
Contributors: codeflavors, constantin.boiangiu
Tags: vimeo, video, video gallery, playlist, gutenberg
Requires at least: 5.2
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 2.3.5.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Import & embed Vimeo in WordPress. Create video galleries & playlists, auto-sync showcases. Gutenberg blocks & Elementor support.

== Description ==

= The Vimeo plugin for WordPress that imports, embeds, and organizes your videos =
Vimeotheque helps you bring Vimeo into WordPress the right way: import videos as posts, auto-sync collections (channels, showcases, portfolios, folders, user uploads), and display beautiful, responsive players and playlists with Gutenberg blocks or shortcodes. Perfect for membership sites, portfolios, online courses and video libraries.

**Highlights**
- **Import & Sync** – Single videos or bulk from channels, showcases, groups, portfolios, folders, user uploads, or Vimeo search.
- **Video as Content** – Creates complete WP posts (title, description, thumbnail, embed) using a dedicated `vimeo-video` post type.
- **Blocks & Shortcodes** – Add single videos, set video position in posts, or build playlists with native Gutenberg blocks. Classic Editor shortcode included.
- **Responsive & Fast** – Uses the latest Vimeo HTML5 player, lazy-load options, “one-video-at-a-time” playback to avoid conflicts, and a no-tracking embed parameter.
- **Elementor-friendly** – Works cleanly inside Elementor layouts; playlists and single embeds drop into any section/column.
- **Templates (optional)** – Enable the plugin’s template system or override in your theme for full design control.

**Use cases**
- **Membership / LMS** – Embed lessons and restrict access with your membership/LMS plugin.
- **Portfolio / Showcase** – Auto-sync a Vimeo showcase/portfolio to your site.
- **Blog / Magazine** – Import as posts and surface videos in archives and widgets.

= PRO adds even more =
- **Automatic bulk imports** (schedule & hands-off sync).
- **Private video imports**.
- **Import as regular posts** (not just the custom post type).
- **Video theme compatibility** and **priority support**.

**Live demo & Docs**
- [Live demo](http://vvp-demo.codeflavors.com)
- [Knowledge Base](https://docs.vimeotheque.com/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=vimeotheque-readme)
- [Getting started with Vimeo OAuth](https://docs.vimeotheque.com/how-to-create-a-new-vimeo-app/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=vimeo-lite-plugin-readme)

== Blocks ==
This plugin provides the following blocks:
1. **Vimeotheque – Video Position** (place the player inside single video posts)
2. **Vimeotheque – Single Video** (embed a specific Vimeo video anywhere)
3. **Vimeotheque – Playlist** (build playlists from imported videos)

== Installation ==
1. Install and activate from **Plugins → Add New**.
2. In **Vimeotheque → Settings → Vimeo authentication**, add your **Vimeo App** credentials (Client ID & Secret).
   Create an app at Vimeo: [developer.vimeo.com/apps/new](https://developer.vimeo.com/apps/new)
   Step-by-step guides:
   - [How to create a new Vimeo App](https://docs.vimeotheque.com/how-to-create-a-new-vimeo-app/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=vimeotheque-readme)
3. Import a single video by URL or use **Bulk Import** for channels, showcases, portfolios, folders, groups, user uploads, or search.
4. Add videos/playlists via the Gutenberg blocks or the Classic Editor shortcode.

== Frequently Asked Questions ==

= Do I need a Vimeo account or app? =
Yes. Create a free Vimeo account, then a Vimeo App and paste the credentials in **Settings → Vimeo authentication** to enable importing.
Step-by-step guide: [docs.vimeotheque.com/how-to-create-a-new-vimeo-app](https://docs.vimeotheque.com/how-to-create-a-new-vimeo-app/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=vimeotheque-readme)

= Can I embed multiple Vimeo videos on one page? =
Yes. Vimeotheque is optimized for multiple embeds and ensures **only one video plays at a time** to prevent conflicts.

= Does it work with Gutenberg and Elementor? =
Yes. You get **three native blocks** for Gutenberg and the output works smoothly inside Elementor sections, columns or templates.

= Can I auto-sync from a Vimeo Showcase, Channel, Portfolio or Folder? =
Yes. Use **Bulk Import** (free) for manual syncing; **Automatic bulk import** (PRO) handles scheduled syncing.

= Can I import private/hidden Vimeo videos? =
Yes, with **Vimeotheque PRO** (subject to Vimeo privacy and API permissions).

= Will thumbnails become featured images? =
Yes. The importer can set the Vimeo thumbnail as the WP featured image on the created post.

= Is there a no-tracking player option? =
Yes. There’s a player parameter to avoid tracking (no cookies/stats). Enable it in the plugin’s embed options.

= Where can I get help? =
Check the [Knowledge Base](https://docs.vimeotheque.com/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=vimeotheque-readme) or open a support topic; PRO users receive priority support.

== Screenshots ==
1. Vimeotheque import single video - step 1
2. Vimeotheque import single video - step 2
3. Vimeotheque import single video - step 3
4. Vimeotheque video position block
5. Vimeotheque single video embed block
6. Vimeotheque single video block usage
7. Vimeotheque playlist block usage
8. Vimeotheque recent videos widget
9. Vimeotheque recent videos widget javascript playlist options
10. Vimeotheque video categories widget
11. Vimeotheque Debug add-on
12. Vimeotheque create status report

== Changelog ==
= 2.3.5.2 =
- Solved WordPress notices that translations were loaded too early;
- Solved bugs related to text used in translations not being displayed or missing translation domain;
- Compatibility with WordPress 6.9.

= 2.3.5.1 =
- Load plugin add-ons information only when needed;
- Changed timeout for the add-ons information to 3s;
- Manage errors returned from Vimeo API queries in a more granular way.

= 2.3.5 =
- Updated code formatting according to WP standards.

= 2.3.4.4 =
- Solved a bug that emitted errors when allowing permissions.

= 2.3.4.3 =
- Solved a bug that could allow SQL injection in certain special cases.

= 2.3.4.2 =
- Implemented shortcode support for Series playlists;
- Implemented shortcode display in Series playlist edit screen;
- Moved theme Carousel script under namespace "vimeotheque".

= 2.3.4.1 =
- Fixed a pagination issue in Series that prevented video posts from being displayed when selecting content.

= 2.3.4 =
- Updated Series theme List options to allow direct navigation to the video post instead of opening the video into the modal window;
- Created new Series theme called Carousel that uses script Flexslider by WooThemes.

= 2.3.3 =
- Updated Block Editor/React components to the new standards imposed by React (ie. removed defaultProps from components) and checked compatibility with WordPress 6.6.

= 2.3.2 =
- Attempt to autoplay lazy-loaded videos when user clicks play. See [https://developer.chrome.com/blog/autoplay/](https://developer.chrome.com/blog/autoplay/) for more details on autoplay.

= 2.3.1 =
- Introduced option for customizable Series slug;
- Solved a bug that generated "404 - Not found" pages when changing slugs for post type, tag or video category from the Vimeotheque Settings page.

= 2.3 =
- Introduced Series, a feature that allow you to create video galleries from imported videos and display them in posts or pages using the Block Editor;
- Solved missing or mismatched translations in plugin;
- Solved unsanitized output issue signaled by PHP Code Sniffer;
- Solved PHP 8 deprecation notice for dynamically generated properties;
- Unified code writing using PHP Code Standards and WP Standards.

= 2.2.9 =
- Added "embed_url" to video Rest API fields;
- Introduced Query Monitor support;
- Introduced filter "vimeotheque-lite/enable-classic-editor-files" that can be used to prevent the plugin from loading the Classic Editor compatibility scripts.

= 2.2.8 =
- Modified Vimeotheque template styling to be less restrictive;
- Added post ID as element data (data-video_id="the post ID") to video embed container.

= 2.2.7 =
- Solved a bug in WP 6.4+ that prevented the Block Editor from loading the Vimeotheque blocks.

= 2.2.6 =
- Solved a bug when importing videos that generated a warning when the Vimeo API query ended with an error that was not issued by the Vimeo API;
- Introduced compatibility for playlists shortcode and block to sort the videos using the menu order; this allows compatibility with Post Types Order plugin to manually order the videos displayed in playlists.

= 2.2.5 =
- Solved a bug that caused responses from the block editor to end up with an undefined variable error.

= 2.2.4 =
- Player embedded by using the player embed URL from the Vimeo API response;
- Separated filter that allows embedding into the post content (vimeotheque\post_content_embed) into a front-end filter and an administration filter (vimeotheque\admin_post_content_embed) to avoid conflicts;
- Introduced filter 'vimeotheque\the_video_embed' that allows the output of templating function vimeotheque_the_video_embed() to be modified.

= 2.2.3 =
- Solved bug that caused broken documentation links to be displayed into the plugin and WP admin area.

= 2.2.2 =
- Solved XSS vulnerability in admin area;
- Solved a bug that caused playlist theme to issue an error.

= 2.2.1 =
- Solved bugs that prevented the title and post content from being properly imported when templates are enabled.

= 2.2 =
- Introduced template system for displaying video posts having post type "vimeo-video" that supports override from the WP theme;
- Added first time "Installation Setup Guide" that gets displayed after the plugin is activated for the first time on the website (doesn't trigger if plugin options are already saved into the database);
- Added plugin Settings option to enable templates. When enabled, several options will have predefined values that can't be changed (ie. the 'vimeo-video' post type visibility in front-end will always be true, descriptions will be imported as post content, the video title and featured image will always get imported);
- Changed the defaults for several options: the tags are set by default to be imported, the video date from Vimeo is set to be imported, the featured image is set to be imported and the default post status is set to "Publish";
- Changed the embedding defaults: the embed width is set by default to 900 and the video volume to 45/100;
- Enabling templates from the plugin Settings page or by adding theme support for templates will disable some options from the Settings page and from importers;
- Created several helper functions that can be used in theme templates to embed the video and display various information about the video;
- Added embed end card functionality that displays a message after the current video playback ends asking if it should automatically load the next video post.

= 2.1.17 =
- Solved a bug that prevented the player from going full screen;
- Solved a compatibility bug with the Classic Editor plugin.

= 2.1.16 =
- Solved a JAvaScript bug in video playlist script that prevented multiple JavaScript playlists from running on the same page.

= 2.1.15 =
- Updated options processing to allow exclusion of options when retrieving the plugin options;
- Added resource "showcase" as a duplicate for "album".

= 2.1.14 =
- Updated various scripts to avoid use of jQuery Migrate;
- Solved PHP 8 specific errors and notices.

= 2.1.13 =
- Updated classes, methods, actions and filters PHPDoc descriptions and parameters.

= 2.1.12 =
- Added new embed option in plugin settings (tab Embed Options) that allows the setup of a maximum player height in the entire website (useful for social network formats, like 9x16 or 1x1).

= 2.1.11 =
- Solved bug in Vimeotheque "Add new" page that generated error when trying to import another video after the previous video was successfully imported;
- Updated Vimeo API reource implementations to flag if a resource is enabled for importers (for resources used in back-end).

= 2.1.10 =
- Added class "video-thumbnail" on the image for lazy loaded videos;
- Implemented JS functionality for centering the image for lazy loaded videos when the image size ratio isn't the same as the video size ratio;
- Implemented CSS functionality for centering lazy loaded images;
- Added new playlist theme called "Simple";
- Added new playlist theme called "Listy";
- Implemented filters in classic widget to allow playlist themes to inject additional options.

= 2.1.8 =
- Added class 'no-lazy' to images to prevent W3 Total Cache from breaking the display in video playlists;
- Solved display bug for videos in portrait mode that were lazy-loaded;
- Solved bug that retrieved the smallest video image instead of the full-size image when the featured image wasn't set and lazy loading was on.

= 2.1.7 =
- Implemented a new filter in Video Position block to allow extra parameters to be set on the iframe URL.

= 2.1.6 =
- Solved a bug in single video import (the Add new page in Vimeotheque) that issued a WP Block Editor error after importing;
- Single video import (the Add new page in Vimeotheque) will import videos having the post status set in the plugin Settings option under "Import Options" as oposed to being set up by default to "Draft".

= 2.1.5 =
- Added detection for duplicate images;
- Added options togglers in Vimeotheque Settings page for easier display of dependant options;
- Solved a WordPress 5.8 Widgets screen error in Vimeotheque blocks;
- Solved various (non critical) bugs.

= 2.1.4 =
- Solved bug that prevented the "Screen Options" and "Help" admin tabs from displaying into the website admin;
- Removed unecessary CSS rules from the bootstrap.css file used for displaying the playlist block and video importer grid columns and renamed the file from bootstrap.min.css to bootstrap.css.

= 2.1.3 =
- Added new filter "vimeotheque\classic_editor\show_shortcode_meta_box" that allows disabling of the shortcode metabox when editing posts with the "Classic editor";
- Solved block editor error "Array to string conversion" caused by wrong parameter type in Vimeotheque playlist block.

= 2.1.2 =
- Added new filter "vimeotheque\duplicate_posts_found" which allows duplicate video posts.

= 2.1.1 =
- Solved a Block Editor error that caused the Vimeotheque Playlist Block to crash when using the playlist block with an option to change the videos order;
- Removed deprecated jQuery functions that caused jQueryMigrate messages in console;
- Improved detection of variables when saving options in WP Admin;
- Solved a bug in Vimeotheque Playlist script that prevented the videos to autoplay one after the other when option to loop the playlist was on;
- Prevented lazy-loading in Vimeotheque Playlists (not needed and counter intuitive).

= 2.1 =
- Added new option in plugin settings "Embed options" for option "Display video" to embed video in video posts in place of the featured image;
- Added new option in plugin settings "Embed options" to lazy load videos;
- Added new option in plugin settings "Embed options" to set the play icon color for lazy loaded videos;
- Added new individual video post option in Classic editor under "Display video" to embed video in place of the featured image;
- Added new individual video post option in Classic editor to lazy load video;
- Added new individual video post option in Block editor under "Embedding options" to replace the featured image with the video embed;
- Added new individual video post option in Block editor under "Embedding options" to lazy load video;
- Solved a rare bug that caused a "TypeError" in some cases (Vimeotheque\Front_End::skipped_autoembed() must be an instance of WP_Post, instance of stdClass given);
- Solved a bug in playlist theme "Default" that wasn't switching the class "active-video" between items when loop option was on.

= 2.0.21 =
- Solved a bug in Video Position Block that cause post saving error/notice when editing a video post managed by Vimeotheque;
- Changed Video Position Block options "Video start time" and "Volume" to range controls;
- Added new option in Video Position Block for video embed background transparency;
- Added new option for videos edited using the Classic Editor to set the video embed background transparency;
- Increased Vimeotheque minimum WordPress version requirement to  WordPress 5.3 ( for support of object meta type in the REST API );
- Made video background transparency a global option in Vimeotheque Settings, under tab "Embed options";
- Solved a bug in Video Player script implemented by Vimeotheque which caused the player to ignore the embed volume option.

= 2.0.20 =
- Solved a bug in Playlist shortcode and Playlist block that prevented manually selected "vimeo-video" posts from being displayed into the playlist while option "Video post is public" was checked in plugin settings;
- Solved a bug in Playlist block that caused the block to crash when selecting videos imported as regular posts while having to PRO add-on active.

= 2.0.19 =
- Solved a bug in playlist theme "Default" that prevented clicking on the read more link when showing the excerpts into the playlist.

= 2.0.18 =
- Solved a bug that issued error "Call to a member function get_page() on null" when Jetpack installed.

= 2.0.17 =
- Added option for muted video in Classic editor;
- Added option for muted video in Video Position block;
- Added option for background mode in Classic editor;
- Added option for background mode in Video Position block;
- Added options dependency in Classic editor which hides options that don't apply when certain options are selected (ie. background mode disables a number of options);
- Added option for Classic editor to set the video start time when editing a video;
- Added option for Block editor to set the video start time when editing a video;
- Order showcases by default by "modified_time";
- Order user uploads feed by default by "date".

= 2.0.16 =
- Solved an issue with importers that were prevented from using the default sorting value;
- Solved a rare bug that caused errors when checking for duplicates and the feed returned from the Vimeo API was empty.

= 2.0.15 =
- Created a new option in Block Editor for playlist theme "Default" to display video thumbnails using the original size ratio (thumbnails in list might have different size) or have them displayed with the same size (thumbnails in list might have black bars);
- Created a new option in Classic Editor shortcode visual interface for theme "Default" to display video thumbnails size ratio in original size or the same size for all thumbnails.

= 2.0.14 =
- Video player adds class "loaded" on the video container once the video is loaded;
- Modified video player display to remove the black background and loader image after the video has loaded;
- Improved processing of tabs in plugin Settings.

= 2.0.13 =
- Solved a bug in Video Playlist Widget that caused the widget to display videos from all categories even if a category was selected from the widget options.

= 2.0.12 =
- Added date limit for showcase and channel;
- Made image preloader in playlist themes to use the 640px wide image version for videos.

= 2.0.11 =
- Solved a bug that caused the Video Playlist Block to crash when custom post type "vimeo-video" had no categories set up;
- Added "empty results" message to Video Playlist Block modal window if there are no categories set up for the plugin's custom post type;
- Improved display of options for Video Playlist Block theme "Default".

= 2.0.10 =
- Solved a bug that prevented the "Add new" plugin admin page from being displayed in some cases (ie. when using WooCommerce without the Classic editor plugin).

= 2.0.9 =
- Solved a bug in single video embed block that was causing the options for "Loop video" and "Autoplay video" to be always on.

= 2.0.8 =
- Solved a bug in block "Video position" which caused the player color to be loaded incorrectly when loading the default color set in plugin Settings under Embed options;
- Improved video position block for Block editor to allow additional parameters to be set;
- Added new parameter to filter "vimeotheque\player\embed-parameters" which passes any manually set embed options;
- Added new action "vimeotheque\automatic_embed_in_content" which is triggered when Vimeotheque embeds videos into the post content automatically (normally, when the Classic editor is used instead of the Block editor);
- Added new action "vimeotheque\editor\classic-editor-options-output" which is triggered when Vimeotheque displays the embedding options in post edit screen in Classic editor;
- Introduced actions and filters that allow third party plugins to add new block editor options to video position block.

= 2.0.7 =
- Added filter "vimeotheque\player\embed-parameters" that allows extra parameters to be added to the video embed iframe URL;
- Updated translation file for Romanian.

= 2.0.6 =
- Created new option for playlist block to display post excerpts in playlists for theme Default;
- Created new option for playlist block to allow various posts ordering options;
- Created new option for playlist widget to display post excerpts in playlists when using theme Default;
- Created new option for playlist shortcode in Classic editor to display post excerpts when using theme Default;
- Created new option for playlist shortcode to allow various posts ordering options;
- Introduced support for AMP plugin.

= 2.0.5 =
- Solved occasional single video import error caused by conflicts with third party plugins;
- Introduced player embed option to prevent tracking users, including all cookies and stats;
- Show manually selected videos in playlist shortcode into the exact order that they were selected;
- Preserve videos order in playlist block same as the order they were selected;
- Hide video position block that is introduced automatically into the block editor for Vimeotheque video posts if automatic embedding is disabled by filter.

= 2.0.4 =
- Stop video player script in case of player error to avoid JavaScript errors in page;
- Re-initialize video playlist script in case the player script returned an error;
- Compatibility with WP plugin "Complianz – GDPR/CCPA Cookie Consent" by "Really Simple Plugins".

= 2.0.3 =
- Solved a bug in Video Position block that disregarded the option to embed videos in archive pages and always embedded them;
- Updated Vimeotheque hooks PHPDoc comments in plugin files;
- Introduced actions and filters to OAuth plugin settings instructions;
- Exposed REST_Api object for new endpoints registrations;
- Introduced Vimeo API request method.

= 2.0.2 =
- Introduced add-ons management that allow installation of add-ons for various purposes;
- Added option for playlist block to set alignment;
- Optimized resizing for playlist block theme Default;
- Added option for video position block to set alignment;
- Added option for single video embed to set alignment;
- Added option to display manual bulk imports by the order set on Vimeo (applies only for showcase, channel, portfolio, user uploads and folder );
- New plugin Settings option for embed alignment.

= 2.0.1 =
* Added changelog file;
* Implemented filters to hide various plugin notices;
* Solved bug that wasn't hiding the video when using the appropriate filter to prevent auto embedding in post content using the block editor.

= 2.0 =
* Plugin requires at least WordPress 5.2 and PHP 5.6;
* Vimeotheque 2 functions as base for Vimeotheque PRO 2;
* Introduced 3 blocks for the block editor: video position (for video posts), single video embed and playlist embed;
* Allows import of more than 1 tag;
* Allows setup of tags when making manual bulk imports;
* Manual bulk import allows search within the results and ordering;
* Allows import of featured image automatically, when the video is imported;
* Redesigned manual bulk import into a friendlier grid interface app;
* Redesigned single video import into a stepped process app;
* Introduced status page that can output environment varialbles useful for debugging;
* Made custom post type video slugs editable from plugin settings; 
* Vimeo player script uses the new Vimeo player API.

= 1.3.5 =
* Introduced user ID parameter to queries for Vimeo showcases.

= 1.3.4 =
* Solved WP 5.4 redirect bug from plugin Settings page;
* Removed contextual help deprecated filter.

= 1.3.3 =
* Solved a bug that prevented video imports when one of the videos in feed had an empty description.

= 1.3.2 =
* Removed SSL verification for requests to Vimeo API to prevent cURL SSL errors on installations with older libraries when making requests to the API.

= 1.3.1 =
* Renamed plugin to "Vimeotheque Lite";
* Redirected all links to new, plugin dedicated URL: https://vimeotheque.com

= 1.3 =
* Added (initial) compatibility with Gutenberg editor.

= 1.2.8 =
* Added search filter when importing videos from user uploads, channels, albums or groups.

= 1.2.7 =
* Added privacy policy information which is displayed into WordPress's Privacy Policy Guide.

= 1.2.6.1 =
* Solved a translation bug that was generating errors in plugin Settings page;
* Modified video post checking to look for the queried object instead of using the global $post variable;
* Converted all necessary Vimeo URLs to https.

= 1.2.6 =
* Added option to import video publish date on Vimeo;
* Added option to import and set 1 video tag retrieved from Vimeo;
* Added option to embed videos by iframe instead of using the JavaScript embedding;
* Added option to allow individual video posts to override the embed aspect ratio set in plugin Settings with the actual ratio of the video;
* Vimeo OAuth API keys are not visible anymore after setting and validating the keys in plugin Settings page;
* Added possibility to import video image as post featured image in video post edit screen;
* Confined review request to be displayed only on plugin pages to avoid WP admin notices clutter;
* Introduced "About" page on plugin activation that displays messages about the current update and other useful information;
* Introduced embed aspect ratio 2.35:1 in addition to 16:9 and 4:3.

= 1.2.5.4 = 
* Added styling to front-end video embed to display a loading icon before video has finished loading in page;
* Minimized front-end video embed script and created a developer file of the script;
* Modified post type "vimeo-video" to also support trackbacks, custom fields, comments, revisions and post formats; 
* Modified video import to set post format to video for all imported Vimeo videos;
* Implemented filter "cvm_import_post_format" that can be used to change post format for all videos that are going to be imported after filter implementation;
* Implemented filters [cvm_video_post_title](https://vimeotheque.com/documentation/vimeo-video-post-filters/cvm_video_post_title/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=vimeo-lite-plugin-readme), [cvm_video_post_content](https://vimeotheque.com/documentation/vimeo-video-post-filters/cvm_video_post_content/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=vimeo-lite-plugin-readme), [cvm_video_post_excerpt](https://vimeotheque.com/documentation/vimeo-video-post-filters/cvm_video_post_excerpt/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=vimeo-lite-plugin-readme) and [cvm_video_post_status](https://vimeotheque.com/documentation/vimeo-video-post-filters/cvm_video_post_status/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=vimeo-lite-plugin-readme).

= 1.2.5.3 =
* Implemented REST API functionality;
* Solved a rare bug when selecting video posts for plugin shortcode that was displaying all registered posts in website instead of only the video posts if a third party script was implementing "pre_get_posts" filter;
* Added new PHP class to handle all WP REST API functionality.

= 1.2.5.2 =
* Solved a JavaScript bug that was preventing volume to be set to 0 (mute);
* Added friendly, user dismissible notice asking for plugin review on WordPress.org (thank you in advance for your review). 

= 1.2.5.1 =
* Solved a JavaScript bug that was preventing the volume setting from being set on videos embedded by the plugin;
* Solved a bug that was setting embed color scheme to red (#FF0000) by default even when not filled.

= 1.2.5 =
* Solved a bug that was displaying the video on password protected posts even if the correct password was not provided;
* Updated several documentation links;
* Added JSON "fields" parameter to requests to Vimeo API in order to increase the number of requests per hour.

= 1.2.4 =
* Updated player embed script to only use the iframe player embed (removed deprecated Flash player entirely).
* Wrapped widget classes in conditional statements to avoid PHP errors when certain page builders are used.

= 1.2.3 = 
* Solves a rare, ocasional mixed content error when using https and images from Vimeo aren't delivered over https.

= 1.2.2 =
* Solved a bug related to playlist shortcode that was preventing videos from being embedded in certain cases.

= 1.2.1 =
* Solved a shortcode bug that was preventing videos from being embedded when using the single video shortcode in pages or posts.

= 1.2 =

* Video embed details available as data-... attributes on video div element;
* Added tags to video post type;
* Added filter 'cvm_automatic_video_embed' that can be used to prevent embeds to be made by the plugin automatically (return false from callback function);
* Added translation files;
* Added various templating and utility functions;
* Now compatible with the [tutorial](https://vimeotheque.com/documentation/advanced-tutorials/using-vimeo-video-post-plugin-in-wp-theme/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=vimeo-lite-plugin-readme "Using Vimeotheque plugin in WordPress theme") on how to create template files for the custom post type.

= 1.1.3 =

* Added custom post type "vimeo-video" archive (modified has_archive parameter to reflect public settings from Plugin settings)

= 1.1.2 =

* Vimeo video player SSL compatible

= 1.1.1 =

* Plugin compatible with WordPress 4.3 (scheduled for release on August 18th, 2015);
* Added Vimeo video albums import (not functional in version 1.1).

= 1.1 =
* Compatibility with Vimeo OAuth2;
* Restructured plugin Settings page into tabs for easier options management.

= 1.0 =
* Initial release

== Upgrade Notice ==
There are no special upgrade notices for now.

== Troubleshooting ==
Tested with the latest WordPress and default themes across major browsers and mobile. If something looks off, please open a support request and include theme, WP version, and browser/device details.