<?php

/**
 * The sidebar.
 */
add_action( 'vimeotheque_sidebar', 'vimeotheque_get_sidebar', 10 );
