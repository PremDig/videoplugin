tinyMCE.addI18n("en.cvm_shortcode",{
	title : "Embed video"
});