<?php
/**
 * Handle for script block-editor.js
 *
 */
return [
  'handle' => 'vimeotheque-series-block-editor-script'
];